import React, { useState, useEffect } from "react";
import Swal from "sweetalert2";
import { getData, putData } from "../../utlis/utility";

export default function EditAccount() {
  const userId = localStorage.getItem("userId");
  const [formData, setFormData] = useState({
    first_name: "",
    last_name: "",
    phone: "",
    email: "",
  });
  const [loading, setLoading] = useState(true);

  const fetchUserData = async () => {
    setLoading(true);
    try {
      const response = await getData(`/biostarapp/user/get/${userId}`);
      if (response?.data) {
        setFormData({
          first_name: response.data.first_name || "",
          last_name: response.data.last_name || "",
          phone: response.data.phone || "",
          email: response.data.email || "",
        });
      } else {
        Swal.fire("Error", "Failed to fetch user data.", "error");
      }
    } catch (error) {
      Swal.fire("Error", "Error fetching user data.", "error");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchUserData();
  }, [userId]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await putData(`/biostarapp/user/updateuser/${userId}`, formData);
      if (response.status) {
        Swal.fire("Success", "Account details updated successfully!", "success");
      } else {
        Swal.fire("Error", "Failed to update account details.", "error");
      }
    } catch (error) {
      Swal.fire("Error", "Error updating account details.", "error");
    }
  };

  if (loading) {
    return <div className="loader text-center">Loading...</div>;
  }

  return (
    <div className="col-lg-9">
      <div className="page-content my-account__edit">
        <div className="my-account__edit-form">
          <form onSubmit={handleSubmit} className="needs-validation">
            <div className="row">
              <div className="col-md-6">
                <div className="form-floating my-3">
                  <input
                    type="text"
                    className="form-control"
                    id="account_first_name"
                    name="first_name"
                    placeholder="First Name"
                    value={formData.first_name}
                    onChange={handleInputChange}
                    required
                  />
                  <label htmlFor="account_first_name">First Name</label>
                </div>
              </div>
              <div className="col-md-6">
                <div className="form-floating my-3">
                  <input
                    type="text"
                    className="form-control"
                    id="account_last_name"
                    name="last_name"
                    placeholder="Last Name"
                    value={formData.last_name}
                    onChange={handleInputChange}
                    required
                  />
                  <label htmlFor="account_last_name">Last Name</label>
                </div>
              </div>
              <div className="col-md-12">
                <div className="form-floating my-3">
                  <input
                    type="text"
                    className="form-control"
                    id="account_display_name"
                    name="phone"
                    placeholder="Phone Number"
                    value={formData.phone}
                    onChange={handleInputChange}
                    required
                  />
                  <label htmlFor="account_display_name">Phone Number</label>
                </div>
              </div>
              <div className="col-md-12">
                <div className="form-floating my-3">
                  <input
                    type="email"
                    className="form-control"
                    id="account_email"
                    name="email"
                    placeholder="Email Address"
                    value={formData.email}
                    onChange={handleInputChange}
                    disabled
                    required
                  />
                  <label htmlFor="account_email">Email Address</label>
                </div>
              </div>

              <div className="col-md-12">
                <div className="my-3">
                  <button className="btn btn-primary" type="submit">
                    Save Changes
                  </button>
                </div>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}
