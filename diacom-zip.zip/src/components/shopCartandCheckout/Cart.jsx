import { useContextElement } from "@/context/Context";
import { Link } from "react-router-dom";
import { useState, useEffect } from "react";
import { postData } from "../../utlis/utility"; // Ensure this handles API requests
import Swal from "sweetalert2"; // Import SweetAlert2
import { toast } from "react-toastify";

export default function Cart() {
  const { cartProducts, setCartProducts, totalPrice, setTotalPrice } = useContextElement();
  const [checkboxes, setCheckboxes] = useState({
    free_shipping: false,
    flat_rate: false,
    local_pickup: false,
  });
  const [grandTotal, setGrandTotal] = useState(0);
  const [tax, setTax] = useState(0);
  const [coupon, setCoupon] = useState(""); // Store coupon code
  const [discount, setDiscount] = useState(0); // New state for discount
  const [cartId, setCartId] = useState(""); // Store cart ID

  useEffect(() => {
    fetchCartData();
  }, []);

  const fetchCartData = async () => {
    try {
      const data = await postData("/biostarapp/user/organix/view/cart");
      if (data?.status && data?.data?.length > 0) {
        const cartDetails = data.data[0].cartDetails;
        setCartId(cartDetails._id); // Store cart ID dynamically

        setCartProducts(
          cartDetails.products.map((product) => ({
            id: product.productId,
            title: product.name,
            imgSrc: product.image,
            price: product.price,
            quantity: product.quantity,
          }))
        );
        setTotalPrice(cartDetails.totalAmount);
        setGrandTotal(cartDetails.totalAmount);
        setTax(cartDetails.cardPaymentTax);
      }
    } catch (error) {
      console.error("Error fetching cart data:", error);
    }
  };

  const applyCoupon = async () => {
    if (!coupon) {
      Swal.fire("Error", "Please enter a coupon code.", "error");
      return;
    }
  
    if (!cartId) {
      Swal.fire("Error", "Cart ID is missing. Try reloading the page.", "error");
      return;
    }
  
    // Create FormData with coupon and cartId dynamically
    //const formData = new FormData();
    //formData.append("code", coupon); // Coupon code from state
    //formData.append("cartId", cartId); // Cart ID from state
  
    try {
      // Ensure postData is correctly handling FormData
      const response = await postData("/biostarapp/user/organix/apply-coupon", {cartId:cartId, code:coupon}, true);
  
      if (response?.status) {
        Swal.fire("Success", "Coupon applied successfully!", "success");
        setDiscount(response.discountAmount || 0); // Set discount
        setGrandTotal(totalPrice - (response.discountAmount || 0)); // Update grand total
      } else {
        Swal.fire("Error", response?.msg || "Failed to apply coupon.", "error");
      }
    } catch (error) {
      console.error("Error applying coupon:", error);
      Swal.fire("Error", "Something went wrong. Please try again.", "error");
    }
  };
  
  
  const removeProduct = async (product) => {
    if (!cartId) {
      Swal.fire("Error", "Cart ID is missing.", "error");
      return;
    }

    try {
      const apiUrl = `/biostarapp/user/organix/product/delete/${cartId}`;
      const payload = { productId: product.id };

      const response = await postData(apiUrl, payload);

      if (response?.status) {
        setCartProducts(prevState => prevState.filter(item => item.id !== product.id));
        Swal.fire("Success", "Product removed from cart!", "success");
        fetchCartData();
      } else {
        Swal.fire("Error", response?.msg || "Failed to remove product.", "error");
      }
    } catch (error) {
      console.error("Error removing product:", error);
      Swal.fire("Error", "Something went wrong. Please try again.", "error");
    }
  };

  const updateQuantity = async (product, type) => {
    if (!cartId) {
      Swal.fire("Error", "Cart ID is missing.", "error");
      return;
    }

    try {
      const apiUrl = `/biostarapp/user/organix/product/${type}/${cartId}`;
      const payload = { productId: product.id };

      const response = await postData(apiUrl, payload);

      if (response?.status) {
        fetchCartData();
      } else {
        Swal.fire("Error", response?.msg || "Failed to update quantity.", "error");
      }
    } catch (error) {
      console.error("Error updating quantity:", error);
      Swal.fire("Error", "Something went wrong. Please try again.", "error");
    }
  };

  return (
    <div className="shopping-cart" style={{ minHeight: "calc(100vh - 300px)" }}>
      <div className="cart-table__wrapper">
        {cartProducts.length ? (
          <>
            <div className="cart-table-wrapper">
              <table className="cart-table">
                <thead>
                  <tr>
                    <th>Product</th>
                    <th></th>
                    <th>Price</th>
                    <th>Quantity</th>
                    <th>Subtotal</th>
                    <th></th>
                  </tr>
                </thead>
                <tbody>
                  {cartProducts.map((elm, i) => (
                    <tr key={i}>
                      <td>
                        <div className="shopping-cart__product-item">
                          <img
                            loading="lazy"
                            src={elm.imgSrc}
                            width="120"
                            height="120"
                            alt="image"
                          />
                        </div>
                      </td>
                      <td>
                        <div className="shopping-cart__product-item__detail">
                          <h4>{elm.title}</h4>
                        </div>
                      </td>
                      <td>${elm.price}</td>
                      <td>
                        <div className="qty-control position-relative">
                          <input
                            type="number"
                            value={elm.quantity}
                            min={1}
                            readOnly
                            className="qty-control__number text-center"
                          />
                          <div onClick={() => updateQuantity(elm, "minus")} className="qty-control__reduce">
                            -
                          </div>
                          <div onClick={() => updateQuantity(elm, "plus")} className="qty-control__increase">
                            +
                          </div>
                        </div>
                      </td>
                      <td>${elm.price * elm.quantity}</td>
                      <td>
                        <a className="remove-cart" onClick={() => removeProduct(elm)}>✖</a>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="cart-summary">
              <h3 className="cart-summary__title">Cart Summary</h3>
              <h6>Do you have any coupon code? Apply here!</h6>
              <div className="coupon-section">
                <input
                  type="text"
                  placeholder="Enter Coupon Code"
                  value={coupon}
                  onChange={(e) => setCoupon(e.target.value)}
                  className="coupon-input"
                />
                <button className="btn btn-primary coupon-button" onClick={applyCoupon}>Apply Coupon</button>
              </div>
              <div className="cart-summary__details">
                <div className="cart-summary__item">
                  <span>Subtotal:</span>
                  <span>${totalPrice}</span>
                </div>

                {discount > 0 && (
                  <div className="cart-summary__item">
                    <span>Discount Amount:</span>
                    <span>${discount}</span>
                  </div>
                )}

                <div className="cart-summary__item">
                  <span>Tax:</span>
                  <span>${tax}</span>
                </div>

                <div className="cart-summary__item cart-summary__item--total">
                  <span>Grand Total:</span>
                  <span>${grandTotal}</span>
                </div>
              </div>
            </div>
          </>
        ) : (
          <>
            <div className="fs-20">Shop cart is empty</div>
            <button className="btn mt-3 btn-light">
              <Link to="/shop-11">Explore Products</Link>
            </button>
          </>
        )}
      </div>
    </div>
  );
}
