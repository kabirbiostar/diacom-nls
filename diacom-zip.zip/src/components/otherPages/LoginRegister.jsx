import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import Swal from "sweetalert2";
import { postData } from "../../utlis/utility";  // Ensure your utility uses fetch

export default function LoginPage() {
  
  const HandleRegisterUser = async (e) => {
    e.preventDefault();

    const formData = new FormData(e.target);
    const formValues = Object.fromEntries(formData.entries());
    const { password, confirm_password } = formValues;

    // Password Match Validation
    if (password !== confirm_password) {
      Swal.fire("Error", "Passwords do not match!", "error");
      return;
    }

    try {
      const response = await postData("/biostarapp/user/registeruser", formValues);
      if (response.status) {
        Swal.fire("Success", response.msg, "success").then(() => {
          navigate("/login_register"); // Redirect to login page
        });
      } else {
        Swal.fire("Error", response?.msg || "Registration failed!", "error");
      }
    } catch (error) {
      Swal.fire("Error", error.message || "Something went wrong!", "error");
    }
  };
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState({ text: "", type: "" });

  const handleLogin = async (e) => {
    e.preventDefault();
    setLoading(true);
    setMessage({ text: "", type: "" });
  
    const formData = new FormData(e.target);
    const loginDetails = Object.fromEntries(formData.entries());
  
    try {
      const response = await postData("/biostarapp/user/login", loginDetails);
      if (response?.data) {
        setMessage({ text: response.msg || "Login successful!", type: "success" });
  
        // Store token and other data
        localStorage.setItem("BioStartToken", response.token);
        localStorage.setItem("userId", response.ID);
  
        // Show success alert first and then navigate
        Swal.fire("Success", response.msg || "Login successful!", "success").then(() => {
          navigate(-1);
        });
      } else {
        Swal.fire("Failed", response.msg || "Login Failed!", "error");
        e.target.reset();
      }
    } catch (error) {
      setMessage({ text: error.message || "Login failed. Please try again.", type: "error" });
    } finally {
      setLoading(false);
    }
  };
  
  return (
    <section className="login-register container">
      <h2 className="d-none">Login & Register</h2>
      <ul className="nav nav-tabs mb-5" id="login_register" role="tablist">
        <li className="nav-item" role="presentation">
          <a
            className="nav-link nav-link_underscore active"
            id="login-tab"
            data-bs-toggle="tab"
            href="#tab-item-login"
            role="tab"
            aria-controls="tab-item-login"
            aria-selected="true"
          >
            Login
          </a>
        </li>
        <li className="nav-item" role="presentation">
          <a
            className="nav-link nav-link_underscore"
            id="register-tab"
            data-bs-toggle="tab"
            href="#tab-item-register"
            role="tab"
            aria-controls="tab-item-register"
            aria-selected="false"
          >
            Register
          </a>
        </li>
      </ul>
      <div className="tab-content pt-2" id="login_register_tab_content">
        <div
          className="tab-pane fade show active"
          id="tab-item-login"
          role="tabpanel"
          aria-labelledby="login-tab"
        >
           <div className="login-form">
           
      <form onSubmit={handleLogin} className="needs-validation">
        <div className="form-floating mb-3">
          <input
            name="email"
            type="email"
            className="form-control form-control_gray"
            placeholder="Email address *"
            required
          />
          <label>Email address *</label>
        </div>

        <div className="pb-3"></div>

        <div className="form-floating mb-3">
          <input
            name="password"
            type="password"
            className="form-control form-control_gray"
            placeholder="Password *"
            required
          />
          <label>Password *</label>
        </div>

        <div className="d-flex align-items-center mb-3 pb-2">
          <div className="form-check mb-0">
            <input
              name="remember"
              className="form-check-input form-check-input_fill"
              type="checkbox"
            />
            <label className="form-check-label text-secondary">Remember me</label>
          </div>
          <Link to="/reset_password" className="btn-text ms-auto">
            Lost password?
          </Link>
        </div>

        <button
          className="btn btn-primary w-100 text-uppercase"
          type="submit"
          disabled={loading}
        >
          {loading ? "Logging In..." : "Log In"}
        </button>

       
      </form>
    </div>
        </div>
        <div
          className="tab-pane fade"
          id="tab-item-register"
          role="tabpanel"
          aria-labelledby="register-tab"
        >
          <div className="register-form">
          <form onSubmit={HandleRegisterUser} className="needs-validation">
      <div className="form-floating mb-3">
        <input
          name="first_name"
          type="text"
          className="form-control form-control_gray"
          placeholder="Firstname"
          required
        />
        <label>First Name</label>
      </div>
      <input type="hidden" name="role" value="2" />
      <div className="form-floating mb-3">
        <input
          name="last_name"
          type="text"
          className="form-control form-control_gray"
          placeholder="Lastname"
          required
        />
        <label>Last Name</label>
      </div>

      <div className="form-floating mb-3">
        <input
          name="phone"
          type="text"
          className="form-control form-control_gray"
          placeholder="Phone Number"
          required
        />
        <label>Phone Number</label>
      </div>

      <div className="form-floating mb-3">
        <input
          name="email"
          type="email"
          className="form-control form-control_gray"
          placeholder="Email"
          required
        />
        <label>Email</label>
      </div>

      <div className="form-floating mb-3">
        <input
          name="password"
          type="password"
          className="form-control form-control_gray"
          placeholder="Password"
          required
        />
        <label>Password</label>
      </div>

      <div className="form-floating mb-3">
        <input
          name="confirm_password"
          type="password"
          className="form-control form-control_gray"
          placeholder="Confirm Password"
          required
        />
        <label>Confirm Password</label>
      </div>

      <div className="d-flex align-items-center mb-3 pb-2">
        <p className="m-0">
          Your personal data will be used to support your experience
          throughout this website, to manage access to your account, and
          for other purposes described in our privacy policy.
        </p>
      </div>

      <button className="btn btn-primary w-100 text-uppercase" type="submit">
        Register
      </button>
    </form>

          </div>
        </div>
      </div>
    </section>
  );
}
