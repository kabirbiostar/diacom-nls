import React, { useState } from "react";
import Swal from "sweetalert2";
import { postData } from "../../utlis/utility";

export default function EditAccount() {
  const userId = localStorage.getItem("userId");
  const [formData, setFormData] = useState({
    oldPassword: "",
    newPassword: "",
    confirmPassword: "",
  });

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    // Validate passwords
    if (formData.newPassword !== formData.confirmPassword) {
      Swal.fire({
        icon: "error",
        title: "Error",
        text: "New password and confirm password do not match.",
      });
      return;
    }

    try {
      const endpoint = "/biostarapp/user/change-password-new";
      const data = {
        oldPassword: formData.oldPassword,
        newPassword: formData.newPassword,
        confirmPassword: formData.confirmPassword,
      };

      const response = await postData(endpoint, data);

      if (response.status) {
        Swal.fire({
          icon: "success",
          title: "Success",
          text: response.msg || "Password successfully changed!",
        });
      } else {
        Swal.fire({
          icon: "error",
          title: "Error",
          text: response.msg || "Failed to change password.",
        });
      }
    } catch (error) {
      Swal.fire({
        icon: "error",
        title: "Error",
        text: error.message || "Failed to change password. Please try again later.",
      });
    }
  };

  return (
    <div className="col-lg-9">
      <div className="page-content my-account__edit">
        <div className="my-account__edit-form">
          <form onSubmit={handleSubmit} className="needs-validation">
            <div className="row">
              <div className="col-md-12">
                <div className="form-floating my-3">
                  <input
                    type="password"
                    className="form-control"
                    id="oldPassword"
                    name="oldPassword"
                    placeholder="Old Password"
                    value={formData.oldPassword}
                    onChange={handleInputChange}
                    required
                  />
                  <label htmlFor="oldPassword">Old Password</label>
                </div>
              </div>

              <div className="col-md-12">
                <div className="form-floating my-3">
                  <input
                    type="password"
                    className="form-control"
                    id="newPassword"
                    name="newPassword"
                    placeholder="New Password"
                    value={formData.newPassword}
                    onChange={handleInputChange}
                    required
                  />
                  <label htmlFor="newPassword">New Password</label>
                </div>
              </div>

              <div className="col-md-12">
                <div className="form-floating my-3">
                  <input
                    type="password"
                    className="form-control"
                    id="confirmPassword"
                    name="confirmPassword"
                    placeholder="Confirm New Password"
                    value={formData.confirmPassword}
                    onChange={handleInputChange}
                    required
                  />
                  <label htmlFor="confirmPassword">Confirm New Password</label>
                </div>
              </div>

              <div className="col-md-12">
                <div className="my-3">
                  <button className="btn btn-primary" type="submit">
                    Change Password
                  </button>
                </div>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}
