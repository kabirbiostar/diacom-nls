import React, { useState, useEffect } from "react";
import Swal from "sweetalert2";
import { postData } from "../../utlis/utility";

export default function AccountOrders() {
  const [invoices, setInvoices] = useState([]);
  const [isLoading, setIsLoading] = useState(false);

  const fetchInvoices = async () => {
    setIsLoading(true);
    const endpoint = "/biostarapp/user/organix/invoice/list";
    const data = {
      sortOrder: -1,
      page: "",
      limit: "5000",
      search: "",
    };

    try {
      const response = await postData(endpoint, data);
      if (response?.data?.List) {
        setInvoices(response.data.List);
      } else {
        Swal.fire("Error", "No invoices found.", "error");
      }
    } catch (error) {
      Swal.fire("Error", "Failed to fetch invoices.", "error");
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchInvoices();
  }, []);

  return (
    <div className="col-lg-9">
      <div className="page-content my-account__orders-list">
        {isLoading ? (
          <div className="text-center py-5">Loading...</div>
        ) : (
          <table className="orders-table">
            <thead>
              <tr>
                <th>Invoice Id</th>
                <th>Date</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              {invoices.length > 0 ? (
                invoices.map((invoice) => (
                  <tr key={invoice._id}>
                    <td>{invoice.invoiceId}</td>
                    <td>{new Date(invoice.createdAt).toISOString().split("T")[0]}</td>
                    <td>
                      <button className="btn btn-primary">Detail</button>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan="3">No data found</td>
                </tr>
              )}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
