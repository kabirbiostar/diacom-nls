import React, { useState, useEffect } from "react";
import Swal from "sweetalert2";
import { getData, postData, putData } from "../../utlis/utility";

export default function Billings() {
  const userId = localStorage.getItem("userId");
  const [countries, setCountries] = useState([]);
  const [states, setStates] = useState([]);
  const [cities, setCities] = useState([]);
  const [formData, setFormData] = useState({
    billingAddress: "",
    billingState: "",
    billingCity: "",
    billingCountry: "",
    billingZipCode: "",
    billingPhone: "",
  });

  // Fetch country list
  const fetchCountryList = async () => {
    try {
      const res = await postData("biostarapp/user/country-list");
      if (res.status) {
        setCountries(res.data);
      }
    } catch (error) {
      console.error("Country Fetch Error:", error);
    }
  };

  // Fetch state list based on selected country
  const fetchStateList = async (countryName) => {
    try {
      const res = await postData("biostarapp/user/state-list", { countryName });
      if (res.status) {
        setStates(res.data);
      } else {
        setStates([]);
      }
    } catch (error) {
      console.error("State Fetch Error:", error);
      setStates([]);
    }
  };

  // Fetch city list based on selected state
  const fetchCityList = async (countryCode, isoCode) => {
    try {
      const res = await postData("biostarapp/user/city-list", { countryCode, isoCode });
      if (res.status) {
        setCities(res.data);
      } else {
        setCities([]);
      }
    } catch (error) {
      console.error("City Fetch Error:", error);
      setCities([]);
    }
  };

  useEffect(() => {
    fetchCountryList();
    fetchUserData();
  }, []);

  const fetchUserData = async () => {
    try {
      const response = await getData(`/biostarapp/user/get/${userId}`);
      if (response && response.data) {
        const { billingCountry, billingState, billingCity } = response.data;

        // Set the initial form data
        setFormData({
          billingAddress: response.data?.billingAddress || "",
          billingState: billingState || "",
          billingCity: billingCity || "",
          billingCountry: billingCountry || "",
          billingZipCode: response.data?.billingZipCode || "",
          billingPhone: response.data?.billingPhone || "",
        });

        // Fetch the states based on the fetched country
        if (billingCountry) {
          fetchStateList(billingCountry);
        }

        // Fetch the cities based on the fetched state
        if (billingCountry && billingState) {
          const countryCode = countries.find((country) => country.name === billingCountry)?.alpha2Code;
          const isoCode = states.find((state) => state.name === billingState)?.isoCode;

          if (countryCode && isoCode) {
            fetchCityList(countryCode, isoCode);
          }
        }
      } else {
        Swal.fire("Error", "Failed to fetch user data.", "error");
      }
    } catch (error) {
      console.error("Error fetching user data:", error);
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleCountryChange = (e) => {
    const selectedCountry = e.target.value;
    setFormData({ ...formData, billingCountry: selectedCountry, billingState: "", billingCity: "" });
    fetchStateList(selectedCountry);
  };

  const handleStateChange = (e) => {
    const selectedState = e.target.value;
    setFormData({ ...formData, billingState: selectedState, billingCity: "" });

    const countryCode = countries.find((country) => country.name === formData.billingCountry)?.alpha2Code;
    const isoCode = states.find((state) => state.name === selectedState)?.isoCode;
    
    if (countryCode && isoCode) fetchCityList(countryCode, isoCode);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await putData(`biostarapp/user/updateuser/${userId}`, formData);
      if (response.status) {
        Swal.fire("Success", "User details successfully updated!", "success");
      } else {
        Swal.fire("Error", "Failed to update user details.", "error");
      }
    } catch (error) {
      Swal.fire("Error", "Error updating user details.", "error");
    }
  };

  return (
    <div className="col-lg-9">
      <div className="page-content my-account__edit">
        <div className="my-account__edit-form">
          <form onSubmit={handleSubmit} className="needs-validation">
            <div className="row">
              <div className="col-md-12">
                <div className="form-floating my-3">
                  <input
                    type="text"
                    className="form-control"
                    id="billingAddress"
                    name="billingAddress"
                    placeholder="Billing Address"
                    value={formData.billingAddress}
                    onChange={handleInputChange}
                    required
                  />
                  <label htmlFor="billingAddress">Billing Address</label>
                </div>
              </div>
              <div className="col-md-12">
                <div className="form-floating my-3">
                  <select
                    className="form-control"
                    id="billingCountry"
                    name="billingCountry"
                    value={formData.billingCountry}
                    onChange={handleCountryChange}
                    required
                  >
                    <option value="">Select Country</option>
                    {countries.map((country) => (
                      <option key={country._id} value={country.name}>
                        {country.name}
                      </option>
                    ))}
                  </select>
                  <label htmlFor="billingCountry">Country</label>
                </div>
              </div>
              <div className="col-md-12">
                <div className="form-floating my-3">
                  <select
                    className="form-control"
                    id="billingState"
                    name="billingState"
                    value={formData.billingState}
                    onChange={handleStateChange}
                    required
                  >
                    <option value="">Select State</option>
                    {states.map((state) => (
                      <option key={state.isoCode} value={state.name}>
                        {state.name}
                      </option>
                    ))}
                  </select>
                  <label htmlFor="billingState">State</label>
                </div>
              </div>
              <div className="col-md-12">
                <div className="form-floating my-3">
                  <select
                    className="form-control"
                    id="billingCity"
                    name="billingCity"
                    value={formData.billingCity}
                    onChange={handleInputChange}
                    required
                  >
                    <option value="">Select City</option>
                    {cities.map((city) => (
                      <option key={city.name} value={city.name}>
                        {city.name}
                      </option>
                    ))}
                  </select>
                  <label htmlFor="billingCity">City</label>
                </div>
              </div>
              <div className="col-md-12">
                <div className="form-floating my-3">
                  <input
                    type="text"
                    className="form-control"
                    id="billingZipCode"
                    name="billingZipCode"
                    placeholder="Zip Code"
                    value={formData.billingZipCode}
                    onChange={handleInputChange}
                    required
                  />
                  <label htmlFor="billingZipCode">Zip Code</label>
                </div>
              </div>
              <div className="col-md-12">
                <div className="form-floating my-3">
                  <input
                    type="number"
                    className="form-control"
                    id="billingPhone"
                    name="billingPhone"
                    placeholder="Phone Number"
                    value={formData.billingPhone}
                    onChange={handleInputChange}
                    required
                  />
                  <label htmlFor="billingPhone">Phone Number</label>
                </div>
              </div>
              <div className="col-md-12">
                <div className="my-3">
                  <button className="btn btn-primary" type="submit">
                    Save Changes
                  </button>
                </div>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}
