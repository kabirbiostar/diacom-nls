import {
  additionalShopPageitems,
  blogmenuItems,
  homePages,
  othersMenuItems,
  othersMenuItems2,
  othersMenuItems3,
  othersMenuItems4,
  othersMenuItems5,
  shopDetails,
  shopList,
} from "@/data/menu";
import { Link, NavLink, useLocation } from "react-router-dom";
import { useEffect } from "react";

export default function    Nav() {
  const { pathname } = useLocation();
  const isMenuActive = (menu) => {
    return menu.split("/")[1] == pathname.split("/")[1];
  };
  const isActiveParentMenu = (menus) => {
    return menus.some(
      (menu) => menu.href.split("/")[1] == pathname.split("/")[1]
    );
  };
  useEffect(() => {
    function setBoxMenuPosition(menu) {
      const scrollBarWidth = 17; // You might need to calculate or define this value
      const limitR = window.innerWidth - menu.offsetWidth - scrollBarWidth;
      const limitL = 0;
      const menuPaddingLeft = parseInt(
        window.getComputedStyle(menu, null).getPropertyValue("padding-left")
      );
      const parentPaddingLeft = parseInt(
        window
          .getComputedStyle(menu.previousElementSibling, null)
          .getPropertyValue("padding-left")
      );
      const centerPos =
        menu.previousElementSibling.offsetLeft -
        menuPaddingLeft +
        parentPaddingLeft;

      let menuPos = centerPos;
      if (centerPos < limitL) {
        menuPos = limitL;
      } else if (centerPos > limitR) {
        menuPos = limitR;
      }

      menu.style.left = `${menuPos}px`;
    }
    document.querySelectorAll(".box-menu").forEach((el) => {
      setBoxMenuPosition(el);
    });
  }, []);
  return (
    <>
      <li className="navigation__item">
        <Link
          to="/"
          className={`navigation__link ${
            isActiveParentMenu(homePages) ? "menu-active" : ""
          }`}
        >
          Home
        </Link>
        {/* <div className="box-menu" style={{ width: "800px" }}>
          <div className="col pe-4">
            <ul className="sub-menu__list list-unstyled">
              {homePages.slice(0, 6).map((elm, i) => (
                <li key={i} className="sub-menu__item">
                  <Link
                    to={elm.href}
                    className={`menu-link menu-link_us-s ${
                      isMenuActive(elm.href) ? "menu-active" : ""
                    }`}
                  >
                    {elm.title}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div className="col pe-4">
            <ul className="sub-menu__list list-unstyled">
              {homePages.slice(6, 12).map((elm, i) => (
                <li key={i} className="sub-menu__item">
                  <Link
                    to={elm.href}
                    className={`menu-link menu-link_us-s ${
                      isMenuActive(elm.href) ? "menu-active" : ""
                    }`}
                  >
                    {elm.title}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div className="col pe-4">
            <ul className="sub-menu__list list-unstyled">
              {homePages.slice(12, 18).map((elm, i) => (
                <li key={i} className="sub-menu__item">
                  <Link
                    to={elm.href}
                    className={`menu-link menu-link_us-s ${
                      isMenuActive(elm.href) ? "menu-active" : ""
                    }`}
                  >
                    {elm.title}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div className="col">
            <ul className="sub-menu__list list-unstyled">
              {homePages.slice(18, 24).map((elm, i) => (
                <li key={i} className="sub-menu__item">
                  <Link
                    to={elm.href}
                    className={`menu-link menu-link_us-s ${
                      isMenuActive(elm.href) ? "menu-active" : ""
                    }`}
                  >
                    {elm.title}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        </div> */}
        {/* <!-- /.box-menu --> */}
      </li>
      <li className="navigation__item">
        <Link
          to="/shop-11"
          className={`navigation__link
           ${isActiveParentMenu(shopList) ? "menu-active" : ""}
           ${isActiveParentMenu(shopDetails) ? "menu-active" : ""}
           ${isActiveParentMenu(additionalShopPageitems) ? "menu-active" : ""}
          `}
        >
          Shop
        </Link>
      </li>
      <li className="navigation__item">
        <Link
          to="/blog_list1"
          className={`navigation__link ${
            isActiveParentMenu(blogmenuItems) ? "menu-active" : ""
          }`}
        >
          Blog
        </Link>
    
        {/* <!-- /.box-menu --> */}
      </li>
      <li className="navigation__item">
        <a
          href="#"
          className={`navigation__link ${
            isActiveParentMenu(othersMenuItems) ? "menu-active" : ""
          }`}
        >
          Pages
        </a>
        <ul className="default-menu list-unstyled">
          {othersMenuItems.map((elm, i) => (
            <li key={i} className="sub-menu__item">
              <Link
                to={elm.href}
                className={`menu-link menu-link_us-s ${
                  isMenuActive(elm.href) ? "menu-active" : ""
                }`}
              >
                {elm.title}
              </Link>
            </li>
          ))}
        </ul>
        {/* <!-- /.box-menu --> */}
      </li>
      <li className="navigation__item">
        <a
          href="#"
          className={`navigation__link ${
            isActiveParentMenu(othersMenuItems2) ? "menu-active" : ""
          }`}
        >
          TOS
        </a>
        <ul className="default-menu list-unstyled">
          {othersMenuItems2.map((elm, i) => (
            <li key={i} className="sub-menu__item">
              <Link
                to={elm.href}
                className={`menu-link menu-link_us-s ${
                  isMenuActive(elm.href) ? "menu-active" : ""
                }`}
              >
                {elm.title}
              </Link>
            </li>
          ))}
        </ul>
        {/* <!-- /.box-menu --> */}
      </li>



      <li className="navigation__item">
        <a
          href="#"
          className={`navigation__link ${
            isActiveParentMenu(othersMenuItems3) ? "menu-active" : ""
          }`}
        >
          Features
        </a>
        <ul className="default-menu list-unstyled">
          {othersMenuItems3.map((elm, i) => (
            <li key={i} className="sub-menu__item">
              <Link
                to={elm.href}
                className={`menu-link menu-link_us-s ${
                  isMenuActive(elm.href) ? "menu-active" : ""
                }`}
              >
                {elm.title}
              </Link>
            </li>
          ))}
        </ul>
        {/* <!-- /.box-menu --> */}
      </li>
      <li className="navigation__item">
        <a
          href="#"
          className={`navigation__link ${
            isActiveParentMenu(othersMenuItems4) ? "menu-active" : ""
          }`}
        >
          Contact Us
        </a>
        <ul className="default-menu list-unstyled">
          {othersMenuItems4.map((elm, i) => (
            <li key={i} className="sub-menu__item">
              <Link
                to={elm.href}
                className={`menu-link menu-link_us-s ${
                  isMenuActive(elm.href) ? "menu-active" : ""
                }`}
              >
                {elm.title}
              </Link>
            </li>
          ))}
        </ul>
        {/* <!-- /.box-menu --> */}
      </li>
      <li className="navigation__item">
        <a
          href="#"
          className={`navigation__link ${
            isActiveParentMenu(othersMenuItems5) ? "menu-active" : ""
          }`}
        >
          Fraud Alerts
        </a>
        <ul className="default-menu list-unstyled">
          {othersMenuItems5.map((elm, i) => (
            <li key={i} className="sub-menu__item">
              <Link
                to={elm.href}
                className={`menu-link menu-link_us-s ${
                  isMenuActive(elm.href) ? "menu-active" : ""
                }`}
              >
                {elm.title}
              </Link>
            </li>
          ))}
        </ul>
        {/* <!-- /.box-menu --> */}
      </li>
      <li className="navigation__item">
        <Link
          to="/about"
          className={`navigation__link ${
            pathname == "/about" ? "menu-active" : ""
          }`}
        >
          About
        </Link>
      </li>
      <li className="navigation__item">
        <Link
          to="/contact"
          className={`navigation__link ${
            pathname == "/contact" ? "menu-active" : ""
          }`}
        >
          Contact
        </Link>
      </li>
    </>
  );
}
