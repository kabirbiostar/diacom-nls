import { Link, useNavigate } from "react-router-dom";
import Swal from "sweetalert2";
import { postData } from "../../utlis/utility";

export default function ResetPassword() {
  const navigate = useNavigate();

  const handleResetPassword = async (e) => {
    e.preventDefault();

    const formData = new FormData(e.target);
    const email = formData.get("login_email");

    if (!email) {
      Swal.fire("Error", "Please enter a valid email address", "error");
      return;
    }

    try {
      const response = await postData("/biostarapp/user/verify_email_reset_password", { email });

      if (response?.status) {
        Swal.fire("Success", response.msg || "Password reset email sent!", "success").then(() => {
          navigate("/login_register");
        });
      } else {
        Swal.fire("Error", response?.msg || "Failed to send reset email!", "error");
      }
    } catch (error) {
      Swal.fire("Error", error.message || "Something went wrong!", "error");
    }
  };

  return (
    <section className="login-register container">
      <h2 className="section-title text-center fs-3 mb-xl-5">Reset Your Password</h2>
      <p>We will send you an email to reset your password</p>
      <div className="reset-form">
        <form onSubmit={handleResetPassword} className="needs-validation">
          <div className="form-floating mb-3">
            <input
              name="login_email"
              type="email"
              className="form-control form-control_gray"
              placeholder="Email address *"
              required
            />
            <label>Email address *</label>
          </div>

          <button className="btn btn-primary w-100 text-uppercase" type="submit">
            Submit
          </button>

          <div className="customer-option mt-4 text-center">
            <span className="text-secondary">Back to</span>
            <Link to="/login_register" className="btn-text js-show-register">
              Login
            </Link>
          </div>
        </form>
      </div>
    </section>
  );
}
